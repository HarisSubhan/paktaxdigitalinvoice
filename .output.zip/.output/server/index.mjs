globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/accountant-desk-BakiHaBW.jpg": {
		"type": "image/jpeg",
		"etag": "\"15ab1-H6wFEtzDjSNNSGSZW21E844oRnk\"",
		"mtime": "2026-09-23T08:21:30.482Z",
		"size": 88753,
		"path": "../public/assets/accountant-desk-BakiHaBW.jpg"
	},
	"/assets/business-owner-1cJHFQPy.jpg": {
		"type": "image/jpeg",
		"etag": "\"24284-xR1vltUWPvNVUAnLFZw14LJLYpo\"",
		"mtime": "2026-09-23T08:21:30.483Z",
		"size": 148100,
		"path": "../public/assets/business-owner-1cJHFQPy.jpg"
	},
	"/assets/demo-D9UsQc35.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1316-vK3NR1KrnmPQmgZf81HiEwhWAcI\"",
		"mtime": "2026-09-23T08:21:30.472Z",
		"size": 4886,
		"path": "../public/assets/demo-D9UsQc35.js"
	},
	"/assets/demo-poster-BzqC_HvP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38-zBelbLhbLaSc3ifTD6gBzGAEjPI\"",
		"mtime": "2026-09-23T08:21:30.473Z",
		"size": 56,
		"path": "../public/assets/demo-poster-BzqC_HvP.js"
	},
	"/assets/demo-poster-LFyZE-mJ.jpg": {
		"type": "image/jpeg",
		"etag": "\"11406-GSYe49LHHCE3WnBsvbLksgQUKoY\"",
		"mtime": "2026-09-23T08:21:30.484Z",
		"size": 70662,
		"path": "../public/assets/demo-poster-LFyZE-mJ.jpg"
	},
	"/assets/digital-invoicing-r5r-XWCT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c23-ihZr41rSEc1BRlyIbmZWB/KVHZU\"",
		"mtime": "2026-09-23T08:21:30.475Z",
		"size": 7203,
		"path": "../public/assets/digital-invoicing-r5r-XWCT.js"
	},
	"/assets/filing-team-DecyX4pc.jpg": {
		"type": "image/jpeg",
		"etag": "\"27c22-gHoWOSjhCow6BnZgBrhff6bqz+c\"",
		"mtime": "2026-09-23T08:21:30.486Z",
		"size": 162850,
		"path": "../public/assets/filing-team-DecyX4pc.jpg"
	},
	"/assets/index-B6gcgfHS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c37f-2+xBepPDeW51Anwsn6r0t1+V2Wk\"",
		"mtime": "2026-09-23T08:21:30.471Z",
		"size": 377727,
		"path": "../public/assets/index-B6gcgfHS.js"
	},
	"/assets/page-shell-CHoDDr6n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"caf-0ij6KGaLBBeycBZuSe5aZVY2XZA\"",
		"mtime": "2026-09-23T08:21:30.477Z",
		"size": 3247,
		"path": "../public/assets/page-shell-CHoDDr6n.js"
	},
	"/assets/restaurant-counter-DyGG1dls.jpg": {
		"type": "image/jpeg",
		"etag": "\"21a00-yun2oTg5AbOqjbW1HsnUrLhhodc\"",
		"mtime": "2026-09-23T08:21:30.487Z",
		"size": 137728,
		"path": "../public/assets/restaurant-counter-DyGG1dls.jpg"
	},
	"/assets/routes-BlAkWDQC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"87d3-uOgXUTdIQZnx5C96PeqCWZWBpEM\"",
		"mtime": "2026-09-23T08:21:30.479Z",
		"size": 34771,
		"path": "../public/assets/routes-BlAkWDQC.js"
	},
	"/assets/stock-trader-B6pRV-1s.jpg": {
		"type": "image/jpeg",
		"etag": "\"296ae-Q7RbGNrtDKGWp1x6ZO35IdUrOoQ\"",
		"mtime": "2026-09-23T08:21:30.488Z",
		"size": 169646,
		"path": "../public/assets/stock-trader-B6pRV-1s.jpg"
	},
	"/assets/styles-BlQ0gd9G.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"19d8b-XGxxRhjL94OHL4wr6p2X9FEE/10\"",
		"mtime": "2026-09-23T08:21:30.489Z",
		"size": 105867,
		"path": "../public/assets/styles-BlQ0gd9G.css"
	},
	"/assets/uncle-tax-zncRJ9Gk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a47-vwCeBtr+aj1Fq7Udc33d/FZTAVY\"",
		"mtime": "2026-09-23T08:21:30.480Z",
		"size": 14919,
		"path": "../public/assets/uncle-tax-zncRJ9Gk.js"
	},
	"/assets/uncle-tax-DZZY0dlw.png": {
		"type": "image/png",
		"etag": "\"a8d74-TZQwJ8aPNrapxLG7y14T4apGNrU\"",
		"mtime": "2026-09-23T08:21:30.491Z",
		"size": 691572,
		"path": "../public/assets/uncle-tax-DZZY0dlw.png"
	},
	"/logo.png": {
		"type": "image/png",
		"etag": "\"bff2-sL8EuhJgrojvc/FA42ZrGwXxfss\"",
		"mtime": "2026-09-21T07:11:27.786Z",
		"size": 49138,
		"path": "../public/logo.png"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"fc0-T3Wg8F17+PIy/XjycAlfwe2FcIM\"",
		"mtime": "2026-09-19T06:20:40.977Z",
		"size": 4032,
		"path": "../public/favicon.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-21T07:11:27.797Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/uncle-tax-guide-CfEZ45kK.mp4": {
		"type": "video/mp4",
		"etag": "\"303e56b-kax1LO8LZBdgZ1HHvQrBzAHlPNk\"",
		"mtime": "2026-09-23T08:21:30.594Z",
		"size": 50586987,
		"path": "../public/assets/uncle-tax-guide-CfEZ45kK.mp4"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_1aad9Q = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_1aad9Q
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
